#version 330 core
out vec4 FragColor;
in vec2 TexCoords;
in vec3 WorldPos;
in vec3 Normal;

// material parameters
uniform vec3 albedo;
uniform float metallic;
uniform float roughness;
uniform float ao;

// ����� �� �׸������� ���� NDF���� �ٸ���
uniform int lineNum;

// lights
uniform vec3 lightPosition;
uniform vec3 lightColor;

uniform vec3 camPos;

const float PI = 3.14159265359;
// ----------------------------------------------------------------------------
float DistributionGGX(vec3 N, vec3 H, float roughness)
{
    float a = roughness * roughness;
    float a2 = a*a;
    float NdotH = max(dot(N, H), 0.0);
    float NdotH2 = NdotH*NdotH;

    float nom   = a2;
    float denom = (NdotH2 * (a2 - 1.0) + 1.0);
    denom = PI * denom * denom;

    return nom / max(denom, 0.0000001); // prevent divide by zero for roughness=0.0 and NdotH=1.0
}
// ----------------------------------------------------------------------------
float GeometrySchlickGGX(float NdotV, float roughness)
{
    float r = (roughness + 1.0);
    float k = (r*r) / 8.0;

    float nom   = NdotV;
    float denom = NdotV * (1.0 - k) + k;

    return nom / denom;
}
// ----------------------------------------------------------------------------
float GeometrySmith(vec3 N, vec3 V, vec3 L, float roughness)
{
    float NdotV = max(dot(N, V), 0.0);
    float NdotL = max(dot(N, L), 0.0);
    float ggx2 = GeometrySchlickGGX(NdotV, roughness);
    float ggx1 = GeometrySchlickGGX(NdotL, roughness);

    return ggx1 * ggx2;
}

// ----------------------------[Beckmann NDF]--------------------------------------
float DistributionBeck(vec3 N, vec3 H, float roughness)
{
    float a = (roughness);
    float a2 = a * a;

    float NdotH = max(dot(N, H), 0.0);
    float NdotH2 = NdotH * NdotH;
    
    float nom = NdotH;
    //float nom = 1.0;
    float denom = PI * a2 * (NdotH2 * NdotH2);

    float gfunction = exp((NdotH - 1.0) / (a2 * NdotH2));
    //float gfunction = sqrt(1.0 - NdotH2) / (a * NdotH);
    return (nom / max(denom, 0.0000001)) * gfunction;
}
//----------------------[Beckmann Geometry Function G1]---------------------------------
float GeometrySchlickBeck(float NdotS, float roughness)
{
    //lambda function���� a�� ���� ��

    float r = roughness;

    float nom = NdotS;

    float denom = r * sqrt(1.0 - (nom * nom));

    return nom / denom;
}

// -------------------------[Beckmann GeometrySmith ����]----------------------------------------
float GeometrySmithBeck(vec3 N, vec3 V, vec3 L, float roughness)
{
    float NdotV = max(dot(N, V), 0.0);
    float NdotL = max(dot(N, L), 0.0);

    //float ggx2 = GeometrySchlickBeck(NdotV, roughness);
    //float ggx1 = GeometrySchlickBeck(NdotL, roughness);
    float lam2 = 0.0;
    float lam1 = 0.0;

    float a2 = GeometrySchlickBeck(NdotV, roughness);
    if(a2 < 1.6)
    {
        lam2 = ((1.0 - (1.259 * a2)) + (0.396 *(a2 * a2))) / ((3.535 * a2) + (2.181 * (a2 * a2)));
    }
    else
    {
        lam2 = 0.0;
    }

    float a1 = GeometrySchlickBeck(NdotL, roughness);
    if(a1 < 1.6)
    {
        lam1 = ((1.0 - (1.259 * a1)) + (0.396 *(a1 * a1))) / ((3.535 * a1) + (2.181 * (a1 * a1)));
    }
    else
    {
        lam1 = 0.0;
    }

    float ggx2 = NdotV / (1.0 + lam2);
    float ggx1 = NdotL / (1.0 + lam1);

    return ggx1 * ggx2;

}

// ----------------------------------------------------------------------------
vec3 fresnelSchlick(float cosTheta, vec3 F0)
{
    return F0 + (1.0 - F0) * pow(max(1.0 - cosTheta, 0.0), 5.0);
}
// ----------------------------------------------------------------------------

void main()
{
    vec3 N = normalize(Normal);
    vec3 V = normalize(camPos - WorldPos);

    // calculate reflectance at normal incidence; if dia-electric (like plastic) use F0 
    // of 0.04 and if it's a metal, use the albedo color as F0 (metallic workflow)    
    //�ݼ��� ��� �˺������� F0�� ����

    vec3 F0 = vec3(0.04); 
    if(metallic < 0.5)
    {
         F0 = vec3(0.04); 
    }
    else
    {
         F0 = vec3(0);
    }

    F0 = mix(F0, albedo, metallic);

    // reflectance equation
    vec3 Lo = vec3(0.0);

        // calculate per-light radiance
        vec3 L = normalize(lightPosition - WorldPos);
        vec3 H = normalize(V + L);
        float distance = length(lightPosition - WorldPos);
        float attenuation = 1.0 / (distance * distance);
        vec3 radiance = lightColor * attenuation;
        
        float NDF = 0;
        float  G = 0;
        //float NDF = DistributionGGX(N, H, roughness);
        //float G = GeometrySmith(N, V, L, roughness);

        if(lineNum == 0)
        {
            NDF = DistributionGGX(N, H, roughness);
            G = GeometrySmith(N, V, L, roughness); //G2 function
        }
        else if(lineNum == 1)
        {
            NDF = DistributionBeck(N, H, roughness);
            G = GeometrySmithBeck(N, V, L, roughness); //G2 function
        } 
        vec3 F = fresnelSchlick(clamp(dot(H, V), 0.0, 1.0), F0);

        vec3 nominator = NDF * G * F;
        float denominator = 4 * max(dot(N, V), 0.0) * max(dot(N, L), 0.0);
        vec3 specular = nominator / max(denominator, 0.001); // prevent divide by zero for NdotV=0.0 or NdotL=0.0

        // kS is equal to Fresnel
        vec3 kS = F;
        // for energy conservation, the diffuse and specular light can't
        // be above 1.0 (unless the surface emits light); to preserve this
        // relationship the diffuse component (kD) should equal 1.0 - kS.
        vec3 kD = vec3(1.0) - kS;
        // multiply kD by the inverse metalness such that only non-metals 
        // have diffuse lighting, or a linear blend if partly metal (pure metals
        // have no diffuse light).
        kD *= 1.0 - metallic;	  

        // scale light by NdotL
        float NdotL = max(dot(N, L), 0.0);        

        // add to outgoing radiance Lo
        Lo += (kD * albedo / PI + specular) * radiance * NdotL;  // note that we already multiplied the BRDF by the Fresnel (kS) so we won't multiply by kS again
    
    // ambient lighting (note that the next IBL tutorial will replace 
    // this ambient lighting with environment lighting).
    vec3 ambient = vec3(0.03) * albedo * ao;

    vec3 color = ambient + Lo;

    // HDR tonemapping
    color = color / (color + vec3(1.0));
    // gamma correct
    color = pow(color, vec3(1.0/2.2)); 

    FragColor = vec4(color, 1.0);
}
